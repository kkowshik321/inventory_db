import { createContext, useState, useEffect } from "react";
import API from "../api/inventoryApi";

export const InventoryContext = createContext();

export const InventoryProvider = ({ children }) => {
  const [items, setItems] = useState([]);
  const [locations, setLocations] = useState([]);
  const [inventory, setInventory] = useState([]);
  const [users, setUsers] = useState([]);
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalItems: 0,
    lowStocks: 0,
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Fetch all users from database
  const fetchUsers = async () => {
    try {
      const response = await API.get("/users");
      setUsers(response.data || []);
    } catch (err) {
      console.error("Error fetching users:", err);
      setError("Failed to fetch users");
    }
  };

  // Fetch all items from database
  const fetchItems = async () => {
    try {
      const response = await API.get("/items");
      setItems(response.data || []);
    } catch (err) {
      console.error("Error fetching items:", err);
      // Fallback to empty array if API fails
      setItems([]);
    }
  };

  // Fetch all locations from database
  const fetchLocations = async () => {
    try {
      const response = await API.get("/locations");
      setLocations(response.data || []);
    } catch (err) {
      console.error("Error fetching locations:", err);
      // Fallback to empty array if API fails
      setLocations([]);
    }
  };

  // Fetch all inventory records from database
  const fetchInventory = async () => {
    try {
      const response = await API.get("/inventory");
      setInventory(response.data || []);
      
      // Calculate low stocks (quantity < 10)
      const lowStocks = (response.data || []).filter(inv => inv.quantity < 10).length;
      setStats(prev => ({ ...prev, lowStocks }));
    } catch (err) {
      console.error("Error fetching inventory:", err);
      // Fallback to empty array if API fails
      setInventory([]);
    }
  };

  // Fetch stats for admin dashboard
  const fetchStats = async () => {
    try {
      setLoading(true);
      await Promise.all([
        fetchUsers(),
        fetchItems(),
        fetchLocations(),
        fetchInventory(),
      ]);
      
      // Update stats after fetching data
      const usersRes = await API.get("/users").catch(() => ({ data: [] }));
      const itemsRes = await API.get("/items").catch(() => ({ data: [] }));
      const inventoryRes = await API.get("/inventory").catch(() => ({ data: [] }));
      
      const lowStocks = (inventoryRes.data || []).filter(inv => inv.quantity < 10).length;
      
      setStats({
        totalUsers: (usersRes.data || []).length,
        totalItems: (itemsRes.data || []).length,
        lowStocks: lowStocks,
      });
      
      setError(null);
    } catch (err) {
      console.error("Error fetching stats:", err);
      setError("Failed to fetch data");
    } finally {
      setLoading(false);
    }
  };

  // Get items by user
  const getItemsByUser = (userId) => {
    return items.filter(item => item.userId === userId);
  };

  // Get locations by user
  const getLocationsByUser = (userId) => {
    return locations.filter(location => location.userId === userId);
  };

  // Get inventory by user
  const getInventoryByUser = (userId) => {
    return inventory.filter(inv => inv.userId === userId);
  };

  const addItem = (item, userId) => {
    try {
      // Send to backend
      API.post("/items", { ...item, userId })
        .then(response => {
          setItems(prev => [...prev, response.data]);
        })
        .catch(err => {
          console.error("Error adding item:", err);
          // Fallback: add locally
          setItems(prev => [...prev, { ...item, id: Math.random(), userId }]);
        });
    } catch (err) {
      console.error("Error adding item:", err);
    }
  };

  const addLocation = (location, userId) => {
    try {
      // Send to backend
      API.post("/locations", { ...location, userId })
        .then(response => {
          setLocations(prev => [...prev, response.data]);
        })
        .catch(err => {
          console.error("Error adding location:", err);
          // Fallback: add locally
          setLocations(prev => [...prev, { ...location, id: Math.random(), userId }]);
        });
    } catch (err) {
      console.error("Error adding location:", err);
    }
  };

  const addInventory = (record, userId) => {
    try {
      // Send to backend
      API.post("/inventory", { ...record, userId })
        .then(response => {
          setInventory(prev => [...prev, response.data]);
          fetchStats(); // Update stats after adding inventory
        })
        .catch(err => {
          console.error("Error adding inventory:", err);
          // Fallback: add locally
          setInventory(prev => [...prev, { ...record, id: Math.random(), userId }]);
        });
    } catch (err) {
      console.error("Error adding inventory:", err);
    }
  };

  // Initialize by fetching data on mount
  useEffect(() => {
    fetchStats();
  }, []);

  return (
    <InventoryContext.Provider
      value={{
        items,
        locations,
        inventory,
        users,
        stats,
        loading,
        error,
        addItem,
        addLocation,
        addInventory,
        fetchStats,
        getItemsByUser,
        getLocationsByUser,
        getInventoryByUser,
      }}
    >
      {children}
    </InventoryContext.Provider>
  );
};
