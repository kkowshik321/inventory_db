﻿import React, { useEffect, useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Search,
  Bell,
  PlusCircle,
  Box,
  MapPin,
  Archive,
  Users,
  AlertTriangle
} from "lucide-react";
import InventoryAPI from "../api/inventoryApi";

export default function UserDashboard() {

  const user = useMemo(() => JSON.parse(localStorage.getItem("user") || "{}"), []);

  const [items, setItems] = useState([]);
  const [locations, setLocations] = useState([]);
  const [inventory, setInventory] = useState([]);
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        setLoading(true);
        const [itemsRes, locationsRes, inventoryRes] = await Promise.all([
          InventoryAPI.get(`/items/user/${user.id}`),
          InventoryAPI.get(`/locations/user/${user.id}`),
          InventoryAPI.get(`/inventory/user/${user.id}`)
        ]);
        setItems(itemsRes.data || []);
        setLocations(locationsRes.data || []);
        setInventory(inventoryRes.data || []);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    })();
  }, [user.id]);

  const lowStock = inventory.filter(i => i.stock <= (i.minimumStock || 0));
  const filteredItems = items.filter(i => i.name?.toLowerCase().includes(query.toLowerCase()));
  const filteredLocations = locations.filter(l => l.locationName?.toLowerCase().includes(query.toLowerCase()));
  const filteredInventory = inventory.filter(inv => (inv.item?.name || "").toLowerCase().includes(query.toLowerCase()) || (inv.location?.locationName || "").toLowerCase().includes(query.toLowerCase()));

  return (
    <div className="min-h-screen bg-[#F8FAFC] p-8">

      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-3xl font-semibold text-[#0F172A]">Welcome back, {user.fullName || "User"} 👋</h2>
          <p className="text-sm text-slate-500">Your inventory snapshot and recent activity</p>
        </div>

        <div className="flex items-center gap-4">
          <div className="relative">
            <input
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="Search items, locations, stocks..."
              className="pl-10 pr-4 py-2 rounded-full w-96 bg-white border border-white/40 shadow-sm text-sm focus:outline-none focus:ring-2 focus:ring-[#2563EB]"
            />
            <Search className="absolute left-3 top-2.5 text-slate-400" size={18} />
          </div>

          <button className="p-2 rounded-lg bg-white/60 backdrop-blur-md border border-white/30 shadow hover:scale-105 transition">
            <Bell className="text-[#0F172A]" />
          </button>

          <div className="flex items-center gap-3 bg-white rounded-xl p-2 shadow">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#2563EB] to-[#7C3AED] flex items-center justify-center text-white font-bold">{(user.fullName || "U").charAt(0)}</div>
            <div className="text-sm">
              <div className="font-medium text-[#0F172A]">{user.fullName || "User"}</div>
              <div className="text-xs text-slate-500">{user.email}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Overview Cards */}
      <div className="grid grid-cols-12 gap-6 mb-8">
        <motion.div layout className="col-span-12 lg:col-span-4 bg-white/60 backdrop-blur-md border border-white/30 rounded-[20px] p-6 shadow-md">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="p-3 rounded-xl bg-gradient-to-br from-[#2563EB] to-[#7C3AED] text-white">
                <Box />
              </div>
              <div>
                <div className="text-sm text-slate-500">My Items</div>
                <motion.div className="text-2xl font-bold text-[#0F172A]" animate={{ opacity: 1 }} initial={{ opacity: 0 }}>{loading ? "—" : items.length}</motion.div>
              </div>
            </div>
            <div className="text-sm text-slate-400">Updated now</div>
          </div>
        </motion.div>

        <motion.div layout className="col-span-12 lg:col-span-4 bg-white/60 backdrop-blur-md border border-white/30 rounded-[20px] p-6 shadow-md">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="p-3 rounded-xl bg-gradient-to-br from-[#22C55E] to-[#16A34A] text-white">
                <MapPin />
              </div>
              <div>
                <div className="text-sm text-slate-500">My Locations</div>
                <motion.div className="text-2xl font-bold text-[#0F172A]" animate={{ opacity: 1 }} initial={{ opacity: 0 }}>{loading ? "—" : locations.length}</motion.div>
              </div>
            </div>
            <div className="text-sm text-slate-400">Client data</div>
          </div>
        </motion.div>

        <motion.div layout className="col-span-12 lg:col-span-4 bg-white/60 backdrop-blur-md border border-white/30 rounded-[20px] p-6 shadow-md">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="p-3 rounded-xl bg-gradient-to-br from-[#F59E0B] to-[#F97316] text-white">
                <Archive />
              </div>
              <div>
                <div className="text-sm text-slate-500">Total Stocks</div>
                <motion.div className="text-2xl font-bold text-[#0F172A]" animate={{ opacity: 1 }} initial={{ opacity: 0 }}>{loading ? "—" : inventory.length}</motion.div>
              </div>
            </div>
            <div className="text-sm text-slate-400">Real-time</div>
          </div>
        </motion.div>
      </div>

      <div className="grid grid-cols-12 gap-6">
        {/* Left column: Tables */}
        <div className="col-span-12 lg:col-span-8 space-y-6">

          {/* My Items Table */}
          <motion.section layout className="bg-white/60 backdrop-blur-md border border-white/30 rounded-[20px] p-6 shadow">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-[#0F172A]">My Items</h3>
              <div className="flex items-center gap-3">
                <button className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[#2563EB] text-white hover:opacity-95 transition"><PlusCircle size={16} /> Add</button>
              </div>
            </div>

            {loading ? (
              <div className="space-y-3">
                <div className="h-4 bg-slate-200 rounded w-3/4 animate-pulse" />
                <div className="h-4 bg-slate-200 rounded w-1/2 animate-pulse" />
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full table-auto">
                  <thead className="text-left text-sm text-slate-500 border-b">
                    <tr>
                      <th className="py-3">Name</th>
                      <th className="py-3">Category</th>
                      <th className="py-3">Description</th>
                      <th className="py-3">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredItems.map(item => (
                      <motion.tr key={item.id} className="hover:bg-white/40 transition" whileHover={{ scale: 1.01 }}>
                        <td className="py-3">{item.name}</td>
                        <td className="py-3 text-sm text-slate-500">{item.category}</td>
                        <td className="py-3 text-sm text-slate-600">{item.description}</td>
                        <td className="py-3">
                          <button className="px-3 py-1 rounded-md bg-[#7C3AED] text-white text-sm">View</button>
                        </td>
                      </motion.tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </motion.section>

          {/* My Locations Table */}
          <motion.section layout className="bg-white/60 backdrop-blur-md border border-white/30 rounded-[20px] p-6 shadow">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-[#0F172A]">My Locations</h3>
              <div className="text-sm text-slate-400">{locations.length} locations</div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredLocations.map(loc => (
                <div key={loc.id} className="p-4 bg-white rounded-xl border border-white/20 shadow-sm flex items-start gap-4">
                  <MapPin className="text-[#2563EB] mt-1" />
                  <div>
                    <div className="font-medium text-[#0F172A]">{loc.locationName}</div>
                    <div className="text-sm text-slate-500">{loc.address}</div>
                  </div>
                </div>
              ))}
            </div>
          </motion.section>

          {/* My Inventory Table */}
          <motion.section layout className="bg-white/60 backdrop-blur-md border border-white/30 rounded-[20px] p-6 shadow">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-[#0F172A]">My Inventory</h3>
              <div className="text-sm text-slate-400">{inventory.length} records</div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full table-auto">
                <thead className="text-left text-sm text-slate-500 border-b">
                  <tr>
                    <th className="py-3">Item</th>
                    <th className="py-3">Location</th>
                    <th className="py-3">Stock</th>
                    <th className="py-3">Min Stock</th>
                    <th className="py-3">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredInventory.map(inv => (
                    <tr key={inv.id} className="hover:bg-white/40 transition">
                      <td className="py-3">{inv.item?.name}</td>
                      <td className="py-3 text-sm text-slate-500">{inv.location?.locationName}</td>
                      <td className="py-3 font-medium">{inv.stock}</td>
                      <td className="py-3">{inv.minimumStock}</td>
                      <td className="py-3">
                        {inv.stock <= (inv.minimumStock || 0) ? (
                          <span className="inline-flex items-center gap-2 px-2 py-1 rounded-full bg-[#EF4444]/10 text-[#EF4444] text-sm">Low</span>
                        ) : (
                          <span className="inline-flex items-center gap-2 px-2 py-1 rounded-full bg-[#22C55E]/10 text-[#16A34A] text-sm">Healthy</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </motion.section>
        </div>

        {/* Right column: Profile + Alerts + Activity */}
        <div className="col-span-12 lg:col-span-4 space-y-6">
          <motion.div layout className="bg-white/60 backdrop-blur-md border border-white/30 rounded-[20px] p-6 shadow">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#2563EB] to-[#7C3AED] flex items-center justify-center text-white text-xl font-bold">{(user.fullName||"U").charAt(0)}</div>
              <div>
                <div className="text-lg font-semibold text-[#0F172A]">{user.fullName}</div>
                <div className="text-sm text-slate-500">{user.email}</div>
                <div className="mt-3 flex gap-2">
                  <button className="px-3 py-1 rounded-md bg-[#2563EB] text-white text-sm">Edit Profile</button>
                  <button className="px-3 py-1 rounded-md bg-white border text-sm">Settings</button>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div layout className="bg-white/60 backdrop-blur-md border border-white/30 rounded-[20px] p-6 shadow">
            <div className="flex items-center justify-between mb-4">
              <h4 className="font-semibold text-[#0F172A]">Low Stock Alerts</h4>
              <div className="text-sm text-slate-400">{lowStock.length} alerts</div>
            </div>
            <div className="space-y-3">
              {lowStock.length === 0 ? (
                <div className="text-sm text-slate-500">No low stock alerts. Great job!</div>
              ) : lowStock.map(l => (
                <div key={l.id} className="flex items-start gap-3 p-3 bg-white rounded-lg border border-white/20">
                  <AlertTriangle className="text-[#EF4444] mt-1" />
                  <div>
                    <div className="font-medium text-[#0F172A]">{l.item?.name} — {l.location?.locationName}</div>
                    <div className="text-sm text-slate-500">Stock: {l.stock} • Min: {l.minimumStock}</div>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>

          <motion.div layout className="bg-white/60 backdrop-blur-md border border-white/30 rounded-[20px] p-6 shadow">
            <h4 className="font-semibold text-[#0F172A] mb-3">Recent Activity</h4>
            <div className="divide-y">
              {inventory.slice(0,6).map(act => (
                <div key={act.id} className="py-3 flex items-start gap-3">
                  <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-slate-500">{act.item?.name?.charAt(0) || "#"}</div>
                  <div>
                    <div className="text-sm text-[#0F172A]">{act.item?.name} updated</div>
                    <div className="text-xs text-slate-400">{new Date(act.updatedAt || act.createdAt || Date.now()).toLocaleString()}</div>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}