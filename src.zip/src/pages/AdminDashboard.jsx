﻿import React, { useEffect, useMemo, useState } from "react";
import Sidebar from "../components/Sidebar";
import InventoryAPI from "../api/inventoryApi";
import { motion } from "framer-motion";
import {
  LayoutDashboard,
  Users,
  Box,
  MapPin,
  Package,
  Search,
  Bell,
  Settings,
  LogIn
} from "lucide-react";

function Sparkline({ data = [] }) {
  const points = data.map((v, i) => `${(i / (data.length - 1 || 1)) * 100},${100 - v}`).join(" ");
  return (
    <svg className="w-full h-16" viewBox="0 0 100 100" preserveAspectRatio="none">
      <polyline fill="none" stroke="#2563EB" strokeWidth="2" points={points} />
    </svg>
  );
}

function AdminDashboard() {
  const [users, setUsers] = useState([]);
  const [items, setItems] = useState([]);
  const [locations, setLocations] = useState([]);
  const [inventory, setInventory] = useState([]);
  const [query, setQuery] = useState("");
  const [selectedUser, setSelectedUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => { fetchData(); }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      const [usersRes, itemsRes, locationsRes, inventoryRes] = await Promise.all([
        InventoryAPI.get("/users"),
        InventoryAPI.get("/items"),
        InventoryAPI.get("/locations"),
        InventoryAPI.get("/inventory")
      ]);
      setUsers(usersRes.data || []);
      setItems(itemsRes.data || []);
      setLocations(locationsRes.data || []);
      setInventory(inventoryRes.data || []);
    } catch (e) {
      console.error("Dashboard Error:", e);
    } finally {
      setLoading(false);
    }
  };

  const recentActivity = inventory.slice(-8).reverse();

  return (
    <div className="flex bg-[#F8FAFC] min-h-screen">
      <Sidebar />

      <div className="ml-64 flex-1 p-8">
        {/* Top nav */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-semibold text-[#0F172A]">Admin Control Center</h1>
            <p className="text-sm text-slate-500">Manage users, inventory and system analytics</p>
          </div>

          <div className="flex items-center gap-4">
            <div className="relative">
              <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search users, items, locations..." className="pl-10 pr-4 py-2 rounded-full w-80 bg-white border border-white/40 shadow-sm text-sm focus:outline-none focus:ring-2 focus:ring-[#2563EB]" />
              <Search className="absolute left-3 top-2.5 text-slate-400" size={16} />
            </div>
            <button className="p-2 rounded-lg bg-white/60 backdrop-blur-md border border-white/30 shadow hover:scale-105 transition"><Bell /></button>
            <button className="px-3 py-2 rounded-md bg-[#2563EB] text-white flex items-center gap-2"><LogIn /> Invite</button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-12 gap-6 mb-8">
          <motion.div layout className="col-span-12 sm:col-span-6 md:col-span-3 bg-white/60 backdrop-blur-md border border-white/30 rounded-[20px] p-5 shadow">
            <div className="text-sm text-slate-500">Users</div>
            <div className="text-2xl font-bold text-[#0F172A]">{loading ? '—' : users.length}</div>
          </motion.div>
          <motion.div layout className="col-span-12 sm:col-span-6 md:col-span-3 bg-white/60 backdrop-blur-md border border-white/30 rounded-[20px] p-5 shadow">
            <div className="text-sm text-slate-500">Items</div>
            <div className="text-2xl font-bold text-[#0F172A]">{loading ? '—' : items.length}</div>
          </motion.div>
          <motion.div layout className="col-span-12 sm:col-span-6 md:col-span-3 bg-white/60 backdrop-blur-md border border-white/30 rounded-[20px] p-5 shadow">
            <div className="text-sm text-slate-500">Locations</div>
            <div className="text-2xl font-bold text-[#0F172A]">{loading ? '—' : locations.length}</div>
          </motion.div>
          <motion.div layout className="col-span-12 sm:col-span-6 md:col-span-3 bg-white/60 backdrop-blur-md border border-white/30 rounded-[20px] p-5 shadow">
            <div className="text-sm text-slate-500">Stocks</div>
            <div className="text-2xl font-bold text-[#0F172A]">{loading ? '—' : inventory.length}</div>
          </motion.div>
        </div>

        <div className="grid grid-cols-12 gap-6">
          {/* Users list */}
          <div className="col-span-12 lg:col-span-4">
            <div className="bg-white/60 backdrop-blur-md border border-white/30 rounded-[20px] p-6 shadow space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-[#0F172A]">Users</h3>
                <div className="text-sm text-slate-400">{users.length}</div>
              </div>

              <div className="space-y-3 max-h-[60vh] overflow-auto">
                {users.filter(u => u.fullName?.toLowerCase().includes(query.toLowerCase()) || u.email?.toLowerCase().includes(query.toLowerCase())).map(u => (
                  <button key={u.id} onClick={() => setSelectedUser(u)} className={`w-full text-left p-3 rounded-xl transition ${selectedUser?.id === u.id ? 'bg-[#2563EB] text-white' : 'bg-white/50 hover:bg-white'} flex items-center gap-3`}>
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#2563EB] to-[#7C3AED] flex items-center justify-center text-white">{u.fullName?.charAt(0)}</div>
                    <div className="flex-1">
                      <div className="font-medium">{u.fullName}</div>
                      <div className="text-xs text-slate-500">{u.email}</div>
                    </div>
                    <div className="text-xs text-slate-400">{u.role?.roleName || 'User'}</div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Details & Analytics */}
          <div className="col-span-12 lg:col-span-8 space-y-6">
            <div className="bg-white/60 backdrop-blur-md border border-white/30 rounded-[20px] p-6 shadow">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-[#0F172A]">Inventory Analytics</h3>
                <div className="text-sm text-slate-400">Last 30 days</div>
              </div>
              <div className="mt-4">
                <Sparkline data={[20,30,40,35,50,60,55,70,80,75,90]} />
              </div>
            </div>

            <div className="bg-white/60 backdrop-blur-md border border-white/30 rounded-[20px] p-6 shadow">
              <h3 className="text-lg font-semibold text-[#0F172A] mb-3">Activity Logs</h3>
              <div className="overflow-x-auto">
                <table className="w-full table-auto">
                  <thead className="text-left text-sm text-slate-500 border-b">
                    <tr>
                      <th className="py-3">Item</th>
                      <th className="py-3">Location</th>
                      <th className="py-3">Stock</th>
                      <th className="py-3">User</th>
                      <th className="py-3">Timestamp</th>
                    </tr>
                  </thead>
                  <tbody>
                    {inventory.slice().reverse().slice(0,20).map(inv => (
                      <tr key={inv.id} className="hover:bg-white/40 transition">
                        <td className="py-3">{inv.item?.name}</td>
                        <td className="py-3 text-sm text-slate-500">{inv.location?.locationName}</td>
                        <td className="py-3">{inv.stock}</td>
                        <td className="py-3 text-sm">{inv.user?.fullName || inv.user?.email}</td>
                        <td className="py-3 text-sm text-slate-400">{new Date(inv.updatedAt || inv.createdAt || Date.now()).toLocaleString()}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Selected User drawer */}
            {selectedUser ? (
              <div className="bg-white/60 backdrop-blur-md border border-white/30 rounded-[20px] p-6 shadow">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#2563EB] to-[#7C3AED] flex items-center justify-center text-white text-xl">{selectedUser.fullName?.charAt(0)}</div>
                    <div>
                      <div className="text-xl font-semibold text-[#0F172A]">{selectedUser.fullName}</div>
                      <div className="text-sm text-slate-500">{selectedUser.email}</div>
                      <div className="mt-2 text-sm text-slate-400">Role: {selectedUser.role?.roleName || 'User'}</div>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button className="px-3 py-2 rounded-md bg-[#2563EB] text-white">Message</button>
                    <button className="px-3 py-2 rounded-md bg-white border">Edit</button>
                  </div>
                </div>

                <div className="mt-6 grid grid-cols-3 gap-4">
                  <div className="p-4 bg-white rounded-xl border border-white/20">
                    <div className="text-sm text-slate-500">Items</div>
                    <div className="text-2xl font-bold">{items.filter(it => it.user?.id === selectedUser.id).length}</div>
                  </div>
                  <div className="p-4 bg-white rounded-xl border border-white/20">
                    <div className="text-sm text-slate-500">Locations</div>
                    <div className="text-2xl font-bold">{locations.filter(l => l.user?.id === selectedUser.id).length}</div>
                  </div>
                  <div className="p-4 bg-white rounded-xl border border-white/20">
                    <div className="text-sm text-slate-500">Stocks</div>
                    <div className="text-2xl font-bold">{inventory.filter(inv => inv.user?.id === selectedUser.id).length}</div>
                  </div>
                </div>
              </div>
            ) : null}
          </div>
        </div>
      </div>
    </div>
  );
}

export default AdminDashboard;